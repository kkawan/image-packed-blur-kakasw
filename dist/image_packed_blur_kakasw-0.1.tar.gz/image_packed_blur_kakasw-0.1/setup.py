from setuptools import setup, find_packages

setup(
    name="image_packed_blur_kakasw",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "Pillow",
    ],
    description="A simple image processing package",
    author="Seu Nome",
    author_email="seuemail@example.com",
    url="https://github.com/kkawan/image_packed_blur_kakasw",
)
