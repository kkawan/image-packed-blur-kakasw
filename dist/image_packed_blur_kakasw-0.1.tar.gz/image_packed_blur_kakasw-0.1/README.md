# Image Processing Package

Este é um pacote simples de processamento de imagens desenvolvido em Python. Ele permite aplicar filtros, redimensionar imagens, e realizar outras operações básicas.

## Instalação

Para instalar o pacote, você pode cloná-lo e instalar as dependências localmente:

```bash
git clone https://github.com/seuusuario/image_processing.git
cd image_processing
pip install -e .
